import { Router } from "express";
import { upload } from "../middleware/upload.js";
import { handleTranscribe } from "../controllers/transcribeController.js";

const router = Router();

// POST /api/transcribe — multipart/form-data, field name "audio"
router.post("/", upload.single("audio"), handleTranscribe);

export default router;
