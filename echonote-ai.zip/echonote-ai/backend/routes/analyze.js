import { Router } from "express";
import { handleAnalyze } from "../controllers/analyzeController.js";

const router = Router();

// POST /api/analyze — JSON body { transcript: string }
router.post("/", handleAnalyze);

export default router;
