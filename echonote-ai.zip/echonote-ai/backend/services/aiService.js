import fetch from "node-fetch";

const ANALYSIS_SCHEMA_PROMPT = (transcript) => `You are EchoNote AI, an assistant that turns raw lecture transcripts into structured study material.

Read the transcript below and respond with ONLY a valid JSON object — no markdown fences, no preamble, no explanation. Follow this exact shape:

{
  "keyPoints": ["string", "..."],
  "todos": ["string", "..."],
  "mcqs": [
    { "question": "string", "options": ["string","string","string","string"], "correctAnswer": 0 }
  ],
  "summary": "string"
}

Rules:
- "keyPoints": 5-10 concise bullet points covering the core ideas of the lecture, in the order they were discussed.
- "todos": 3-6 actionable study tasks a student should do after this lecture (e.g. review a topic, prepare for a quiz, finish an assignment) — base these on anything explicitly mentioned in the transcript, and add sensible generic revision tasks if nothing specific was mentioned.
- "mcqs": exactly 10 multiple choice questions testing understanding of the lecture content. Each must have exactly 4 options and "correctAnswer" as the zero-based index (0-3) of the correct option.
- "summary": a summary readable aloud in about 60 seconds (roughly 130-160 words), written in clear plain prose.
- Do not invent facts that contradict the transcript. If the transcript is short, still produce all fields as best you can from the available content.

Transcript:
"""
${transcript}
"""`;

async function analyzeWithGemini(transcript) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    const err = new Error("GEMINI_API_KEY is not set on the server.");
    err.status = 500;
    throw err;
  }
  const model = process.env.GEMINI_MODEL || "gemini-2.0-flash";
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: ANALYSIS_SCHEMA_PROMPT(transcript) }] }],
      generationConfig: {
        temperature: 0.4,
        responseMimeType: "application/json",
      },
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    const err = new Error(`Gemini request failed: ${errText}`);
    err.status = 502;
    err.publicMessage = "AI analysis failed. Please try again.";
    throw err;
  }

  const data = await response.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) {
    const err = new Error("Gemini returned no content.");
    err.status = 502;
    throw err;
  }
  return text;
}

async function analyzeWithOpenAI(transcript) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    const err = new Error("OPENAI_API_KEY is not set on the server.");
    err.status = 500;
    throw err;
  }
  const model = process.env.OPENAI_TEXT_MODEL || "gpt-4o-mini";

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      temperature: 0.4,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: "You output only valid JSON, matching the schema you are given." },
        { role: "user", content: ANALYSIS_SCHEMA_PROMPT(transcript) },
      ],
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    const err = new Error(`OpenAI request failed: ${errText}`);
    err.status = 502;
    err.publicMessage = "AI analysis failed. Please try again.";
    throw err;
  }

  const data = await response.json();
  const text = data?.choices?.[0]?.message?.content;
  if (!text) {
    const err = new Error("OpenAI returned no content.");
    err.status = 502;
    throw err;
  }
  return text;
}

function safeParseJson(raw) {
  let cleaned = raw.trim();
  // Strip markdown code fences if the model added them despite instructions
  cleaned = cleaned.replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
  try {
    return JSON.parse(cleaned);
  } catch (e) {
    const err = new Error(`Failed to parse AI response as JSON: ${e.message}`);
    err.status = 502;
    err.publicMessage = "AI returned an unexpected format. Please try again.";
    throw err;
  }
}

function validateShape(parsed) {
  const required = ["keyPoints", "todos", "mcqs", "summary"];
  for (const key of required) {
    if (!(key in parsed)) {
      const err = new Error(`AI response missing required field: ${key}`);
      err.status = 502;
      throw err;
    }
  }
  return parsed;
}

/**
 * Analyzes a transcript and returns { keyPoints, todos, mcqs, summary }
 * Provider is chosen via AI_PROVIDER env var: "gemini" (default) or "openai"
 */
export async function analyzeTranscript(transcript) {
  const provider = (process.env.AI_PROVIDER || "gemini").toLowerCase();
  const rawText = provider === "openai" ? await analyzeWithOpenAI(transcript) : await analyzeWithGemini(transcript);
  const parsed = safeParseJson(rawText);
  return validateShape(parsed);
}
