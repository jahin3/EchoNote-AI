import fs from "fs";
import FormData from "form-data";
import fetch from "node-fetch";

const WHISPER_URL = "https://api.openai.com/v1/audio/transcriptions";

/**
 * Sends an audio file to OpenAI's Whisper API and returns the transcript text.
 * @param {string} filePath - absolute path to the audio file on disk
 * @returns {Promise<string>} transcript
 */
export async function transcribeAudio(filePath) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    const err = new Error("OPENAI_API_KEY is not set on the server.");
    err.status = 500;
    throw err;
  }

  const form = new FormData();
  form.append("file", fs.createReadStream(filePath));
  form.append("model", "whisper-1");
  form.append("response_format", "json");

  const response = await fetch(WHISPER_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      ...form.getHeaders(),
    },
    body: form,
  });

  if (!response.ok) {
    const errText = await response.text();
    const err = new Error(`Whisper transcription failed: ${errText}`);
    err.status = response.status === 401 ? 500 : 502;
    err.publicMessage = "Transcription failed. Please try again with a clearer recording.";
    throw err;
  }

  const data = await response.json();
  return data.text?.trim() || "";
}
