// Wraps async route handlers so thrown errors reach errorHandler instead of crashing the process
export const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

export function notFound(req, res, next) {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.originalUrl}` });
}

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  console.error("[EchoNote API Error]", err);

  const status = err.status || err.statusCode || 500;
  const message = err.publicMessage || err.message || "Something went wrong on the server.";

  res.status(status).json({
    error: message,
    ...(process.env.NODE_ENV !== "production" ? { detail: err.stack } : {}),
  });
}
