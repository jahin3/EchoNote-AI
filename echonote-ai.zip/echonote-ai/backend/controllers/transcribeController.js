import fs from "fs";
import { transcribeAudio } from "../services/whisperService.js";
import { asyncHandler } from "../middleware/errorHandler.js";

export const handleTranscribe = asyncHandler(async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "No audio file was uploaded. Attach a file under field name 'audio'." });
  }

  const filePath = req.file.path;

  try {
    const transcript = await transcribeAudio(filePath);
    if (!transcript) {
      return res.status(422).json({ error: "Could not detect any speech in the recording. Try again with clearer audio." });
    }
    res.json({ transcript });
  } finally {
    // Clean up the uploaded file regardless of outcome
    fs.unlink(filePath, () => {});
  }
});
