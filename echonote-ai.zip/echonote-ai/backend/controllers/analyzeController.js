import { analyzeTranscript } from "../services/aiService.js";
import { asyncHandler } from "../middleware/errorHandler.js";

export const handleAnalyze = asyncHandler(async (req, res) => {
  const { transcript } = req.body;

  if (!transcript || typeof transcript !== "string" || transcript.trim().length < 20) {
    return res.status(400).json({ error: "Provide a transcript of at least 20 characters in the request body." });
  }

  const result = await analyzeTranscript(transcript.trim());
  res.json(result);
});
