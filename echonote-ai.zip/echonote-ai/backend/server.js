import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import transcribeRouter from "./routes/transcribe.js";
import analyzeRouter from "./routes/analyze.js";
import { errorHandler, notFound } from "./middleware/errorHandler.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || "http://localhost:5173";

// --- Core middleware ---
app.use(
  cors({
    origin: CLIENT_ORIGIN,
    methods: ["GET", "POST", "OPTIONS"],
  })
);
app.use(express.json({ limit: "2mb" }));

// --- Health check ---
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", service: "EchoNote AI backend", time: new Date().toISOString() });
});

// --- Routes ---
app.use("/api/transcribe", transcribeRouter);
app.use("/api/analyze", analyzeRouter);

// --- 404 + error handling (must be last) ---
app.use(notFound);
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`EchoNote AI backend running on http://localhost:${PORT}`);
});
