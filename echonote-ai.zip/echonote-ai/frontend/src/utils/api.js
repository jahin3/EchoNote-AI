const API_BASE = import.meta.env.VITE_API_URL || "";

async function parseErrorResponse(response) {
  try {
    const data = await response.json();
    return data.error || `Request failed with status ${response.status}`;
  } catch {
    return `Request failed with status ${response.status}`;
  }
}

/**
 * Uploads an audio Blob/File to the backend for transcription.
 * @param {Blob} audioFile
 * @returns {Promise<string>} transcript text
 */
export async function transcribeAudio(audioFile) {
  const formData = new FormData();
  const filename = audioFile.name || `recording-${Date.now()}.webm`;
  formData.append("audio", audioFile, filename);

  const response = await fetch(`${API_BASE}/api/transcribe`, {
    method: "POST",
    body: formData,
  });

  if (!response.ok) throw new Error(await parseErrorResponse(response));

  const data = await response.json();
  return data.transcript;
}

/**
 * Sends a transcript to the backend for AI analysis.
 * @param {string} transcript
 * @returns {Promise<{keyPoints: string[], todos: string[], mcqs: object[], summary: string}>}
 */
export async function analyzeTranscript(transcript) {
  const response = await fetch(`${API_BASE}/api/analyze`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ transcript }),
  });

  if (!response.ok) throw new Error(await parseErrorResponse(response));

  return response.json();
}
