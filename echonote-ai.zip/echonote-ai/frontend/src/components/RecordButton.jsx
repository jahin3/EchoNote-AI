import { useRecorder } from "../hooks/useRecorder.js";
import { useEffect } from "react";

function formatTime(totalSeconds) {
  const m = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
  const s = String(totalSeconds % 60).padStart(2, "0");
  return `${m}:${s}`;
}

export default function RecordButton({ onRecordingComplete }) {
  const { isRecording, seconds, audioBlob, error, isSupported, start, stop, reset } = useRecorder();

  useEffect(() => {
    if (audioBlob) {
      onRecordingComplete(audioBlob);
      reset();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [audioBlob]);

  return (
    <div className="glass-card flex flex-col items-center gap-4 p-8">
      <button
        onClick={isRecording ? stop : start}
        disabled={!isSupported}
        aria-label={isRecording ? "Stop recording" : "Start recording"}
        className={`relative flex h-24 w-24 items-center justify-center rounded-full text-white shadow-glass-lg transition-transform duration-200 hover:scale-105 active:scale-95 disabled:opacity-40 ${
          isRecording ? "bg-red-500 animate-pulse-ring" : "bg-brand-gradient"
        }`}
      >
        {isRecording ? (
          <span className="h-6 w-6 rounded-md bg-white" />
        ) : (
          <svg width="30" height="30" viewBox="0 0 24 24" fill="white">
            <path d="M12 14a3 3 0 003-3V5a3 3 0 10-6 0v6a3 3 0 003 3zm5-3a5 5 0 01-10 0H5a7 7 0 006 6.92V21h2v-3.08A7 7 0 0019 11h-2z" />
          </svg>
        )}
      </button>

      <div className="text-center">
        <p className="font-mono text-sm text-ink-900/60 dark:text-slate-400">
          {isRecording ? formatTime(seconds) : "Tap to record"}
        </p>
        {isRecording && <p className="mt-1 text-xs font-medium text-red-500">● Recording live</p>}
      </div>

      {!isSupported && (
        <p className="max-w-xs text-center text-xs text-amber-600 dark:text-amber-400">
          Recording isn't supported in this browser. Use the upload option instead.
        </p>
      )}
      {error && <p className="max-w-xs text-center text-xs text-red-500">{error}</p>}
    </div>
  );
}
