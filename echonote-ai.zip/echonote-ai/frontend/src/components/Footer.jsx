export default function Footer() {
  return (
    <footer className="mt-16 border-t border-white/30 dark:border-white/10 py-8 text-center text-xs text-ink-900/40 dark:text-slate-500">
      <p>EchoNote AI — Record once. Learn smarter. · Built with React, Whisper &amp; Gemini</p>
    </footer>
  );
}
