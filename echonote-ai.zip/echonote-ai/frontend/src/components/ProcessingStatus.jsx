const STEPS = [
  { key: "uploading", label: "Uploading audio" },
  { key: "transcribing", label: "Transcribing speech" },
  { key: "analyzing", label: "Generating notes" },
  { key: "done", label: "Done" },
];

export default function ProcessingStatus({ status }) {
  if (status === "idle") return null;

  const currentIndex = STEPS.findIndex((s) => s.key === status);

  return (
    <div className="glass-card mx-auto mt-6 w-full max-w-lg p-6">
      <div className="flex items-center justify-between">
        {STEPS.map((step, i) => {
          const isComplete = i < currentIndex || status === "done";
          const isActive = i === currentIndex && status !== "done";
          return (
            <div key={step.key} className="flex flex-1 flex-col items-center">
              <div className="flex w-full items-center">
                <div
                  className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-bold transition-colors ${
                    isComplete
                      ? "bg-brand-gradient text-white"
                      : isActive
                      ? "border-2 border-brand-500 text-brand-600 dark:text-brand-300"
                      : "border-2 border-ink-900/10 dark:border-white/10 text-ink-900/30 dark:text-slate-500"
                  }`}
                >
                  {isComplete ? "✓" : i + 1}
                </div>
                {i < STEPS.length - 1 && (
                  <div
                    className={`h-0.5 flex-1 transition-colors ${
                      i < currentIndex ? "bg-brand-500" : "bg-ink-900/10 dark:bg-white/10"
                    }`}
                  />
                )}
              </div>
              <span
                className={`mt-2 text-center text-[11px] font-medium ${
                  isActive ? "text-brand-600 dark:text-brand-300" : "text-ink-900/50 dark:text-slate-400"
                }`}
              >
                {step.label}
              </span>
            </div>
          );
        })}
      </div>
      {status !== "done" && (
        <div className="mt-5 flex items-center justify-center gap-2 text-xs text-ink-900/50 dark:text-slate-400">
          <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-400 border-t-transparent" />
          Hang tight, this usually takes a few seconds...
        </div>
      )}
    </div>
  );
}
