import { useRef, useState } from "react";
import TranscriptTab from "./tabs/TranscriptTab.jsx";
import KeyPointsTab from "./tabs/KeyPointsTab.jsx";
import TodoTab from "./tabs/TodoTab.jsx";
import MCQTab from "./tabs/MCQTab.jsx";
import SummaryTab from "./tabs/SummaryTab.jsx";
import { exportElementToPdf, copyText } from "../utils/pdfExport.js";

const TABS = [
  { key: "transcript", label: "Transcript" },
  { key: "keyPoints", label: "Key Points" },
  { key: "todos", label: "To-Do" },
  { key: "mcqs", label: "MCQs" },
  { key: "summary", label: "Summary" },
];

export default function ResultsTabs({ result }) {
  const [activeTab, setActiveTab] = useState("summary");
  const [copyState, setCopyState] = useState("idle");
  const [pdfState, setPdfState] = useState("idle");
  const printRef = useRef(null);

  const { transcript, keyPoints, todos, mcqs, summary } = result;

  async function handleCopy() {
    const text = buildPlainText(result);
    const ok = await copyText(text);
    setCopyState(ok ? "copied" : "error");
    setTimeout(() => setCopyState("idle"), 2000);
  }

  async function handleDownloadPdf() {
    setPdfState("generating");
    try {
      await exportElementToPdf(printRef.current, "EchoNote-Notes.pdf");
    } catch {
      setPdfState("error");
      setTimeout(() => setPdfState("idle"), 2000);
      return;
    }
    setPdfState("idle");
  }

  return (
    <div className="glass-card mx-auto mt-6 w-full max-w-3xl p-5 sm:p-8">
      {/* Tab nav + actions */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1.5">
          {TABS.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`tab-pill ${activeTab === tab.key ? "tab-pill-active" : "tab-pill-inactive"}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          <button onClick={handleCopy} className="btn-ghost text-xs">
            {copyState === "copied" ? "Copied ✓" : copyState === "error" ? "Failed" : "Copy"}
          </button>
          <button onClick={handleDownloadPdf} disabled={pdfState === "generating"} className="btn-primary px-4 py-2 text-xs">
            {pdfState === "generating" ? "Preparing PDF..." : "Download PDF"}
          </button>
        </div>
      </div>

      {/* Active tab content */}
      <div>
        {activeTab === "transcript" && <TranscriptTab transcript={transcript} />}
        {activeTab === "keyPoints" && <KeyPointsTab keyPoints={keyPoints} />}
        {activeTab === "todos" && <TodoTab todos={todos} />}
        {activeTab === "mcqs" && <MCQTab mcqs={mcqs} />}
        {activeTab === "summary" && <SummaryTab summary={summary} />}
      </div>

      {/* Off-screen printable sheet used for PDF export (captures everything, not just active tab) */}
      <div ref={printRef} className="pointer-events-none fixed -left-[9999px] top-0 w-[720px] bg-white p-10 text-ink-900">
        <PrintableSheet result={result} />
      </div>
    </div>
  );
}

function PrintableSheet({ result }) {
  const { transcript, keyPoints, todos, mcqs, summary } = result;
  return (
    <div className="font-body">
      <div className="mb-6 flex items-center gap-3 border-b-4 border-ink-900 pb-4">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-gradient text-lg">🎙️</div>
        <div>
          <div className="font-display text-xl font-bold">EchoNote AI — Lecture Notes</div>
          <div className="font-mono text-[11px] text-ink-900/50">{new Date().toLocaleDateString()}</div>
        </div>
      </div>

      <Section title="60-Second Summary"><p className="text-sm leading-7">{summary}</p></Section>

      <Section title="Key Points">
        <ol className="list-decimal space-y-1.5 pl-5 text-sm">
          {(keyPoints || []).map((p, i) => <li key={i}>{p}</li>)}
        </ol>
      </Section>

      <Section title="To-Do">
        <ul className="space-y-1.5 text-sm">
          {(todos || []).map((t, i) => (
            <li key={i} className="flex gap-2"><span className="mt-1 h-3 w-3 shrink-0 rounded border border-ink-900" />{t}</li>
          ))}
        </ul>
      </Section>

      <Section title="MCQs (with answers)">
        <div className="space-y-3 text-sm">
          {(mcqs || []).map((q, qi) => (
            <div key={qi}>
              <p className="font-semibold">{qi + 1}. {q.question}</p>
              {q.options.map((opt, oi) => (
                <p key={oi} className={oi === q.correctAnswer ? "pl-4 font-semibold text-brand-700" : "pl-4 text-ink-900/70"}>
                  {String.fromCharCode(97 + oi)}) {opt}{oi === q.correctAnswer ? " ✓" : ""}
                </p>
              ))}
            </div>
          ))}
        </div>
      </Section>

      <Section title="Full Transcript"><p className="whitespace-pre-wrap text-xs leading-6 text-ink-900/70">{transcript}</p></Section>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div className="mb-6 break-inside-avoid">
      <h4 className="mb-2 border-b border-ink-900/15 pb-1.5 font-display text-sm font-bold">{title}</h4>
      {children}
    </div>
  );
}

function buildPlainText({ transcript, keyPoints = [], todos = [], mcqs = [], summary }) {
  const lines = [];
  lines.push("EchoNote AI — Lecture Notes\n");
  lines.push("## 60-Second Summary\n" + summary + "\n");
  lines.push("## Key Points");
  keyPoints.forEach((p, i) => lines.push(`${i + 1}. ${p}`));
  lines.push("\n## To-Do");
  todos.forEach((t) => lines.push(`- [ ] ${t}`));
  lines.push("\n## MCQs");
  mcqs.forEach((q, qi) => {
    lines.push(`${qi + 1}. ${q.question}`);
    q.options.forEach((opt, oi) => {
      lines.push(`   ${String.fromCharCode(97 + oi)}) ${opt}${oi === q.correctAnswer ? " (correct)" : ""}`);
    });
  });
  lines.push("\n## Transcript\n" + transcript);
  return lines.join("\n");
}
