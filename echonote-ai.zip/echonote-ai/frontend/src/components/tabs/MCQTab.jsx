import { useState } from "react";

export default function MCQTab({ mcqs = [] }) {
  const [selected, setSelected] = useState({});

  function pick(qIndex, optIndex) {
    if (selected[qIndex] !== undefined) return; // lock after first answer
    setSelected((prev) => ({ ...prev, [qIndex]: optIndex }));
  }

  const answeredCount = Object.keys(selected).length;
  const correctCount = Object.entries(selected).filter(
    ([qIndex, optIndex]) => mcqs[qIndex]?.correctAnswer === optIndex
  ).length;

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h3 className="font-display text-sm font-bold uppercase tracking-wide text-ink-900/50 dark:text-slate-400">
          MCQ Quiz
        </h3>
        {answeredCount > 0 && (
          <span className="rounded-full bg-brand-gradient-soft px-3 py-1 text-xs font-semibold text-brand-700 dark:text-brand-300">
            {correctCount}/{answeredCount} correct
          </span>
        )}
      </div>

      <div className="space-y-6">
        {mcqs.map((q, qi) => {
          const answer = selected[qi];
          const isAnswered = answer !== undefined;
          return (
            <div key={qi} className="border-b border-white/40 pb-5 last:border-none dark:border-white/10">
              <p className="mb-3 text-sm font-semibold text-ink-900/90 dark:text-slate-100">
                {qi + 1}. {q.question}
              </p>
              <div className="grid gap-2 sm:grid-cols-2">
                {q.options.map((opt, oi) => {
                  let stateClass = "border-white/50 dark:border-white/10 bg-white/40 dark:bg-white/5 hover:bg-white/70 dark:hover:bg-white/10";
                  if (isAnswered) {
                    if (oi === q.correctAnswer) {
                      stateClass = "border-emerald-400 bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300";
                    } else if (oi === answer) {
                      stateClass = "border-red-400 bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-300";
                    } else {
                      stateClass = "border-white/30 bg-white/20 opacity-60 dark:border-white/5 dark:bg-white/5";
                    }
                  }
                  return (
                    <button
                      key={oi}
                      onClick={() => pick(qi, oi)}
                      disabled={isAnswered}
                      className={`rounded-xl border p-3 text-left text-sm transition-colors disabled:cursor-default ${stateClass}`}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
