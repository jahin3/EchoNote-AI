import { useState } from "react";

export default function TodoTab({ todos = [] }) {
  const [checked, setChecked] = useState(() => new Set());

  function toggle(i) {
    setChecked((prev) => {
      const next = new Set(prev);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });
  }

  return (
    <div>
      <h3 className="mb-3 font-display text-sm font-bold uppercase tracking-wide text-ink-900/50 dark:text-slate-400">
        To-Do Checklist
      </h3>
      <ul className="space-y-2">
        {todos.map((todo, i) => (
          <li key={i}>
            <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-white/40 dark:border-white/10 bg-white/40 dark:bg-white/5 p-3 text-sm transition-colors hover:bg-white/70 dark:hover:bg-white/10">
              <input
                type="checkbox"
                checked={checked.has(i)}
                onChange={() => toggle(i)}
                className="mt-0.5 h-4 w-4 shrink-0 rounded accent-brand-600"
              />
              <span className={checked.has(i) ? "text-ink-900/40 line-through dark:text-slate-500" : "text-ink-900/85 dark:text-slate-200"}>
                {todo}
              </span>
            </label>
          </li>
        ))}
      </ul>
    </div>
  );
}
