export default function SummaryTab({ summary }) {
  return (
    <div>
      <div className="mb-3 flex items-center gap-2">
        <span className="rounded-full bg-brand-gradient-soft px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-brand-700 dark:text-brand-300">
          60-second summary
        </span>
      </div>
      <p className="text-[15px] leading-8 text-ink-900/85 dark:text-slate-200">
        {summary || "No summary available."}
      </p>
    </div>
  );
}
