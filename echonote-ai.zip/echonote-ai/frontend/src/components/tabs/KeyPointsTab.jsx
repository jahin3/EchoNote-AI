export default function KeyPointsTab({ keyPoints = [] }) {
  return (
    <div>
      <h3 className="mb-3 font-display text-sm font-bold uppercase tracking-wide text-ink-900/50 dark:text-slate-400">
        Key Points
      </h3>
      <ul className="space-y-3">
        {keyPoints.map((point, i) => (
          <li key={i} className="flex items-start gap-3 text-sm text-ink-900/85 dark:text-slate-200">
            <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-brand-gradient-soft text-xs font-bold text-brand-700 dark:text-brand-300">
              {i + 1}
            </span>
            <span className="leading-relaxed">{point}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
