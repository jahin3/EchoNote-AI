export default function TranscriptTab({ transcript }) {
  return (
    <div>
      <h3 className="mb-3 font-display text-sm font-bold uppercase tracking-wide text-ink-900/50 dark:text-slate-400">
        Full Transcript
      </h3>
      <p className="whitespace-pre-wrap text-sm leading-relaxed text-ink-900/85 dark:text-slate-200">
        {transcript || "No transcript available."}
      </p>
    </div>
  );
}
