export default function Hero() {
  return (
    <section className="relative overflow-hidden px-4 pb-6 pt-14 text-center sm:pt-20">
      {/* ambient gradient blobs */}
      <div className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-brand-400/30 blur-3xl animate-float" />
      <div className="pointer-events-none absolute top-10 right-0 h-56 w-56 rounded-full bg-blue-400/20 blur-3xl animate-float [animation-delay:1.5s]" />

      <div className="relative mx-auto max-w-2xl">
        <span className="mb-4 inline-block rounded-full border border-brand-300/50 bg-white/50 dark:bg-white/5 dark:border-white/15 px-4 py-1 text-xs font-semibold tracking-wide text-brand-700 dark:text-brand-300 backdrop-blur-md">
          🎙️ AI-Powered Lecture Notes
        </span>
        <h1 className="font-display text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl">
          EchoNote <span className="bg-brand-gradient bg-clip-text text-transparent">AI</span>
        </h1>
        <p className="mt-4 text-lg font-medium text-ink-900/70 dark:text-slate-300">
          Record once. Learn smarter.
        </p>
        <p className="mx-auto mt-3 max-w-md text-sm text-ink-900/55 dark:text-slate-400">
          Record or upload any lecture and get key points, a to-do list, MCQs, and a 60-second summary — instantly.
        </p>
      </div>
    </section>
  );
}
