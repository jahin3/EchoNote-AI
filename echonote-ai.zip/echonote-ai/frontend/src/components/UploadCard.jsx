import { useRef, useState } from "react";

const ACCEPTED_TYPES = [".mp3", ".wav", ".m4a", ".webm", ".ogg"];
const MAX_SIZE_MB = 25;

export default function UploadCard({ onFileSelected }) {
  const inputRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState(null);

  function validateAndSend(file) {
    if (!file) return;
    setError(null);

    const ext = "." + file.name.split(".").pop().toLowerCase();
    if (!ACCEPTED_TYPES.includes(ext)) {
      setError(`Unsupported file type "${ext}". Please use mp3, wav, m4a, webm, or ogg.`);
      return;
    }
    if (file.size > MAX_SIZE_MB * 1024 * 1024) {
      setError(`File is too large. Max size is ${MAX_SIZE_MB}MB.`);
      return;
    }
    onFileSelected(file);
  }

  return (
    <div
      className={`glass-card flex flex-col items-center gap-3 border-2 border-dashed p-8 text-center transition-colors ${
        isDragging ? "border-brand-500 bg-brand-50/60 dark:bg-brand-500/10" : "border-transparent"
      }`}
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragging(true);
      }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setIsDragging(false);
        validateAndSend(e.dataTransfer.files?.[0]);
      }}
    >
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-gradient-soft text-brand-600 dark:text-brand-300">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
          <polyline points="17 8 12 3 7 8" />
          <line x1="12" y1="3" x2="12" y2="15" />
        </svg>
      </div>
      <p className="font-semibold">Drop an audio file here</p>
      <p className="text-xs text-ink-900/50 dark:text-slate-400">MP3, WAV, M4A, WEBM, OGG · up to {MAX_SIZE_MB}MB</p>

      <button className="btn-ghost mt-1 text-sm" onClick={() => inputRef.current?.click()}>
        Browse files
      </button>
      <input
        ref={inputRef}
        type="file"
        accept={ACCEPTED_TYPES.join(",")}
        className="hidden"
        onChange={(e) => validateAndSend(e.target.files?.[0])}
      />

      {error && <p className="text-xs text-red-500">{error}</p>}
    </div>
  );
}
