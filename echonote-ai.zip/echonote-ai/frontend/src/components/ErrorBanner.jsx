export default function ErrorBanner({ message, onDismiss }) {
  if (!message) return null;
  return (
    <div className="mx-auto mt-6 flex w-full max-w-lg items-start gap-3 rounded-2xl border border-red-300/60 bg-red-50/80 p-4 text-sm text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300">
      <span className="mt-0.5">⚠️</span>
      <p className="flex-1">{message}</p>
      <button onClick={onDismiss} aria-label="Dismiss error" className="text-red-500 hover:text-red-700 dark:hover:text-red-200">
        ✕
      </button>
    </div>
  );
}
