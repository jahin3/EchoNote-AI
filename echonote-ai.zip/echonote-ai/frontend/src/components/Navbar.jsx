import Logo from "./Logo.jsx";
import ThemeToggle from "./ThemeToggle.jsx";

export default function Navbar({ theme, onToggleTheme }) {
  return (
    <header className="sticky top-0 z-40 border-b border-white/30 dark:border-white/10 bg-white/50 dark:bg-ink-950/60 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6">
        <div className="flex items-center gap-2.5">
          <Logo size={34} />
          <span className="font-display text-lg font-bold tracking-tight">
            EchoNote <span className="bg-brand-gradient bg-clip-text text-transparent">AI</span>
          </span>
        </div>
        <ThemeToggle theme={theme} onToggle={onToggleTheme} />
      </div>
    </header>
  );
}
