export default function Logo({ size = 40, className = "" }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="EchoNote AI logo"
    >
      <defs>
        <linearGradient id="echoGradInline" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#7C4DFF" />
          <stop offset="100%" stopColor="#3B82F6" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="18" fill="url(#echoGradInline)" />
      <path d="M20 32c0-4 2-7 4-7" stroke="white" strokeWidth="2.5" strokeLinecap="round" fill="none" opacity="0.55" />
      <path d="M15 32c0-7 3.5-12 7-12" stroke="white" strokeWidth="2.5" strokeLinecap="round" fill="none" opacity="0.35" />
      <path d="M44 32c0-4-2-7-4-7" stroke="white" strokeWidth="2.5" strokeLinecap="round" fill="none" opacity="0.55" />
      <path d="M49 32c0-7-3.5-12-7-12" stroke="white" strokeWidth="2.5" strokeLinecap="round" fill="none" opacity="0.35" />
      <rect x="27" y="16" width="10" height="20" rx="5" fill="white" />
      <path d="M21 30v2a11 11 0 0 0 22 0v-2" stroke="white" strokeWidth="3" strokeLinecap="round" fill="none" />
      <line x1="32" y1="43" x2="32" y2="49" stroke="white" strokeWidth="3" strokeLinecap="round" />
      <line x1="25" y1="49" x2="39" y2="49" stroke="white" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}
