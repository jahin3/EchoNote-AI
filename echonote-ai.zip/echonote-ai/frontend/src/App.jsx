import { useState } from "react";
import Navbar from "./components/Navbar.jsx";
import Hero from "./components/Hero.jsx";
import RecordButton from "./components/RecordButton.jsx";
import UploadCard from "./components/UploadCard.jsx";
import ProcessingStatus from "./components/ProcessingStatus.jsx";
import ResultsTabs from "./components/ResultsTabs.jsx";
import ErrorBanner from "./components/ErrorBanner.jsx";
import Footer from "./components/Footer.jsx";
import { useTheme } from "./hooks/useTheme.js";
import { transcribeAudio, analyzeTranscript } from "./utils/api.js";

// status: idle | uploading | transcribing | analyzing | done
export default function App() {
  const { theme, toggleTheme } = useTheme();
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);

  async function processAudio(audioFile) {
    setError(null);
    setResult(null);
    try {
      setStatus("uploading");
      // brief tick so the "uploading" step is visibly reached before the network call resolves
      await new Promise((r) => setTimeout(r, 300));

      setStatus("transcribing");
      const transcript = await transcribeAudio(audioFile);

      setStatus("analyzing");
      const analysis = await analyzeTranscript(transcript);

      setResult({ transcript, ...analysis });
      setStatus("done");
    } catch (err) {
      setError(err.message || "Something went wrong. Please try again.");
      setStatus("idle");
    }
  }

  const isProcessing = status !== "idle" && status !== "done";

  return (
    <div className="min-h-screen">
      <Navbar theme={theme} onToggleTheme={toggleTheme} />

      <main className="mx-auto max-w-6xl px-4 pb-20 sm:px-6">
        <Hero />

        {!isProcessing && status !== "done" && (
          <div className="mx-auto grid max-w-3xl gap-5 sm:grid-cols-2">
            <RecordButton onRecordingComplete={processAudio} />
            <UploadCard onFileSelected={processAudio} />
          </div>
        )}

        <ErrorBanner message={error} onDismiss={() => setError(null)} />

        <ProcessingStatus status={status} />

        {status === "done" && result && (
          <>
            <ResultsTabs result={result} />
            <div className="mt-6 text-center">
              <button
                onClick={() => {
                  setStatus("idle");
                  setResult(null);
                }}
                className="btn-ghost text-sm"
              >
                ↺ Process another lecture
              </button>
            </div>
          </>
        )}
      </main>

      <Footer />
    </div>
  );
}
