/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#f3f1ff",
          100: "#e9e5ff",
          200: "#d5cdff",
          300: "#b7a6ff",
          400: "#9573ff",
          500: "#7c4dff",
          600: "#6c2fff",
          700: "#5b1fe0",
          800: "#4a1bb3",
          900: "#3d1a8c",
        },
        ink: {
          950: "#0b0a1a",
          900: "#0f0e24",
          800: "#161433",
        },
      },
      fontFamily: {
        display: ["'Sora'", "system-ui", "sans-serif"],
        body: ["'Inter'", "system-ui", "sans-serif"],
      },
      backgroundImage: {
        "brand-gradient": "linear-gradient(135deg, #6c2fff 0%, #7c4dff 45%, #3b82f6 100%)",
        "brand-gradient-soft": "linear-gradient(135deg, rgba(124,77,255,0.18) 0%, rgba(59,130,246,0.14) 100%)",
      },
      boxShadow: {
        glass: "0 8px 32px 0 rgba(31, 20, 90, 0.18)",
        "glass-lg": "0 20px 60px -12px rgba(76, 29, 210, 0.35)",
      },
      animation: {
        "pulse-ring": "pulse-ring 1.6s cubic-bezier(0.4,0,0.6,1) infinite",
        float: "float 6s ease-in-out infinite",
      },
      keyframes: {
        "pulse-ring": {
          "0%, 100%": { boxShadow: "0 0 0 0 rgba(124,77,255,0.45)" },
          "50%": { boxShadow: "0 0 0 18px rgba(124,77,255,0)" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-10px)" },
        },
      },
      backdropBlur: {
        xs: "2px",
      },
    },
  },
  plugins: [],
};
